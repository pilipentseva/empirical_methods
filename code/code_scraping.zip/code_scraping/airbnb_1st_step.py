## Imorting necessary modules
import requests
from bs4 import BeautifulSoup
import time
import datetime
from selenium import webdriver
from openpyxl import Workbook
import io
from threading import Thread
import os, errno


## Setting neighbourhoods lists
neighbours = []

## Setting proxies
proxies = ['194.126.237.17:1212',
            '77.237.228.141:1212',
            '50.117.102.76:1212',
            '50.117.102.75:1212',
            '50.117.102.240:1212',
            '50.117.102.179:1212',
            '77.237.228.141:1212',
            '193.17.219.72:1212',
            '194.126.237.11:1212',
            '31.187.66.134:1212']


## Importing neihbourhood and storing into negihbours[]
with io.open('cntr_sf.txt', "r", encoding="utf-8") as f:
        for q in f:
            neighbours.append(q.replace('neighborhoods%5B%5D=', '').replace('\n',''))

#url = 'https://www.airbnb.com/s/paris/homes?room_types%5B%5D=Entire%20home%2Fapt&room_types%5B%5D=Private%20room&price_max=' +str(price_max)+ '&price_min=' + str(price_min)



## Wraping the whole process in a function
def scrape_process(name, number, range_num, max_price, starting_num):

	## Function for making directory if doesnot exist. Takes filename as parameter
	def make_dir(filename):
		if not os.path.exists(os.path.dirname(filename)):
			try:
				os.makedirs(os.path.dirname(filename))
			except OSError as exc: # Guard against race condition
				if exc.errno != errno.EEXIST:
					raise

	## Function for scrolling thorugh bottom
	def scroll_through_bottom():
		s = 0
		while s <= 4000:
			s = s+200
			browser.execute_script('window.scrollTo(0, '+ str(s) +');')

	
	## Function for getting all the links
	def get_links():
		link_data = browser.find_elements_by_class_name('_1szwzht')
		for link in link_data:
			link_tag = link.find_elements_by_tag_name('a')
			for l in link_tag:
				link_list.append(l.get_attribute("href"))

		print(len(link_list))

	print(name + ' thread is started')



	## Setting proxies when chorme driver will open
	PROXY = proxies[number]
	print(PROXY + ' are using')
	chrome_options = webdriver.ChromeOptions()	
	chrome_options.add_argument('--proxy-server=%s' % PROXY)

	browser = webdriver.Chrome(chrome_options=chrome_options)

	## Setting price range
	max_num = max_price
	price_min = starting_num
	price_max = starting_num + range_num

	## Setting list_list lisr
	link_list = []

	## Starting loop
	while price_max <= max_num:

		url = 'https://www.airbnb.com/s/san-francisco/homes?room_types%5B%5D=Entire%20home%2Fapt&room_types%5B%5D=Private%20room&price_max=' +str(price_max)+ '&price_min=' + str(price_min)
		price_min = price_min + range_num

		price_max = price_max + range_num

		for neighbour in neighbours:

			link = url + '&allow_override%5B%5D=&neighborhoods%5B%5D='+ str(neighbour)
			try:

				browser.get(link)

				time.sleep(5)

				## This will find the element of pagination if does not exist to go through all the pagination
				if browser.find_elements_by_class_name('_1szwzht') != []:

					## This will scroll through bottom for loadin all the data
					scroll_through_bottom()

					# This will get all the links
					get_links()
					print('Zero Phage')

					for data in browser.find_elements_by_class_name('_11hau3k'):
						print('First phage')
						try:

							# This will click pagination next to 17
							data.find_element_by_class_name("_1yofwd5").click()
							print('Second phage')
						except:
							print('Fifth Phage')
						time.sleep(5.5)

						while True:
							try:
								try:
									scroll_through_bottom()
									get_links()
									print('Sixth Phage')
								
									data.find_elements_by_class_name("_1rltvky")[1].click()

									time.sleep(6.5)
									print('Third Phage')
								except IndexError:
									break
								
							except:
								break
				else:
					print('Fourth Phage')
					pass
			except:
				pass

	## Removing all the duplicates from the list
	link_list = list(set(link_list))

	print(str(len(link_list))  + ' total links')

	file_name = 'San-francisco/'+'link_list'+ str(name) +'.txt'
	make_dir(file_name)


	## Writing files to the local directory
	with io.open(file_name, "w", encoding="utf-8") as f:
			
		for links in link_list: 
			f.write(str(links) + '\n')
		print('All links exported to + ' + str(file_name))

	browser.close()



## Starting threads
def Main():
    t1 = Thread(target=scrape_process, args=('Number-1', 0, 2 ,50, 10)) 
    t2 = Thread(target=scrape_process, args=('Number-2', 1, 2 , 100, 50)) 
    t3 = Thread(target=scrape_process, args=('Number-3', 2, 2 , 150, 100))
    t4 = Thread(target=scrape_process, args=('Number-4', 3, 2 , 200, 150))
    t5 = Thread(target=scrape_process, args=('Number-5', 4, 2 , 250, 200))
    t6 = Thread(target=scrape_process, args=('Number-6', 5, 2 , 300, 250))

    t7 = Thread(target=scrape_process, args=('Number-7', 6, 2 ,350, 300)) 
    t8 = Thread(target=scrape_process, args=('Number-8', 7, 2 ,400, 350)) 
    t9 = Thread(target=scrape_process, args=('Number-9', 8, 2 , 450, 400))
    t10 = Thread(target=scrape_process, args=('Number-10', 9, 2 , 500, 450))
    t11 = Thread(target=scrape_process, args=('Number-11', 0, 5 , 700, 500))
    t12 = Thread(target=scrape_process, args=('Number-12', 1, 5 , 1000, 700))


    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t9.start()
    t10.start()
    t11.start()
    t12.start()
    
    print('Main Complete')
    
if __name__ == '__main__':
    Main()