# Importing necesarry modules
from selenium import webdriver
from bs4 import BeautifulSoup
import io
import os, errno
from threading import Thread
import time

# Setting lists

city_name = 'san-francisco'

links = []
proxies = ['50.117.102.179:1212 ',
            '77.237.228.141:1212',
            '193.17.219.72:1212',
            '194.126.237.11:1212',
            '31.187.66.134:1212']

# Wrapping all the code in one function for multi-threading
def scrape_process(name,number,starting_num,end_number):
    print(name +' started!')
    PROXY = proxies[number] # Setting proxies by index
    print(PROXY + ' are using')

    # This function will scroll through bottom of the page
    def scroll_through_bottom():
        s = 0
        while s <= 8000:
            s = s+200
            browser.execute_script('window.scrollTo(0, '+ str(s) +');')

            # This will scroll through bottom but slowly.
    def scroll_through_bottom_slowly():
        s = 0
        while s <= 7000:
            s = s+200
            browser.execute_script('window.scrollTo(0, '+ str(s) +');')
            time.sleep(2)


    # A function which will make directory if doesnot exist
    def make_dir(filename):
        if not os.path.exists(os.path.dirname(filename)):
            try:
                os.makedirs(os.path.dirname(filename))
            except OSError as exc: # Guard against race condition
                if exc.errno != errno.EEXIST:
                    raise


    


    # This function will scrape html data and will save into locally
    def get_html_data():
        scroll_through_bottom()
        html = browser.page_source
        soup = BeautifulSoup(html, "html.parser")

        replace_string = "?location="+ city_name

        id_number = link.replace('https://www.airbnb.com/rooms/', '').replace(replace_string ,'')
        filename = city_name + '_data/' + 'ID' + str(id_number) + '.txt'
        make_dir(filename)

        with io.open(filename, "w", encoding="utf-8") as f:
            f.write(str(soup))
            
        print(str(link) + '  Done')
        print()
        print(str(filename) + ' saved locally')
        lefting_num = int(end_number) - (index+1)
        print('Listing left: ' + str(lefting_num) + ' in ' + name)
        print()

    # Setting proxy in chrome driver
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--proxy-server=%s' % PROXY)

    browser = webdriver.Chrome(chrome_options=chrome_options)

    # Getting Airbnb and Setting currency as Euro
    browser.get('https://fr.airbnb.com')
    #browser.get('https://api.ipify.org/')
    scroll_through_bottom_slowly()
    browser.find_element_by_xpath('//*[@id="currency-selector"]').click()
    time.sleep(2)
    browser.find_element_by_xpath('//*[@id="currency-selector"]/option[15]').click()




    # Opening london listing
    with io.open('link_list_sf.txt', "r", encoding="utf-8") as f:
            for q in f:
                links.append(q.replace('\n',''))

    links[:] = [item for item in links if item != ''] # This line will remove any blank value from list

    # Taking index and value from list by index range
    for index, link in enumerate(links[int(starting_num):int(end_number)]):
        
        browser.get(link.replace(replace_string ,''))

        get_html_data()



    browser.close()


# Used for multi-threading
def Main():
    t1 = Thread(target=scrape_process, args=('Thread-1',0,'0','10000')) 
    t2 = Thread(target=scrape_process, args=('Thread-2', 1,'10000','20000')) 
    t3 = Thread(target=scrape_process, args=('Thread-3', 2,'20000','30000'))
    t4 = Thread(target=scrape_process, args=('Thread-4', 3,'30000','40000'))
    t5 = Thread(target=scrape_process, args=('Thread-5', 4,'40000','42371'))

    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    
    print('Main Complete')
    
if __name__ == '__main__':
    Main()
